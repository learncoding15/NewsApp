/**
 * 
 */
package com.newsapp.newsapp.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import com.newsapp.newsapp.entity.Article;
import com.newsapp.newsapp.entity.NewsAppAttributes;
import com.newsapp.newsapp.entity.NewsAppsUser;
import com.newsapp.newsapp.repository.NewsAppsUserRepository;
import com.newsapp.newsapp.service.NewsAppsUserService;

import jakarta.annotation.PostConstruct;
import jakarta.persistence.GeneratedValue;

/**+=+=
 * @author Lenovo
 *
 */
@Controller
public class NewsAppsUserController {

	@Autowired
	NewsAppsUserService newsAppsUserService;

	@Autowired
	NewsAppsUserRepository userRepository;
	
	
	

	/**
	 * @param newsAppsUserService
	 */
	public NewsAppsUserController(NewsAppsUserService newsAppsUserService) {
		super();
		this.newsAppsUserService = newsAppsUserService;
	}

	// working fine to show the login page only
	@GetMapping("/login")
	public String login() {
 
		return "login";                                    
	}     
	
	@GetMapping("/")
	public String home() {
 
		return "home";                                    
	}    
                                                           
	@GetMapping("/register")                               
	public String register() {                             
                                                           
		return "register";                                 
	}                                                      

	// now we have to validate the user for slighlty use the secure method like post
	// which hide the user pass and user name
	@PostMapping("/validateuser") // to bind the data from the frent hend to database
	public String saveOrValidateUser(@ModelAttribute NewsAppsUser newsAppsUser) {

		String username = newsAppsUser.getEmail();
		String password = newsAppsUser.getPassword();

		System.out.println(username + "       " + password);

		if (username.length() > 0 && password.length() > 0) {

			boolean statusUserLogin = newsAppsUserService.validateUser(username, password);

			if (statusUserLogin) {

				return "redirect:/api";

			} else {
				// if invalid credentials
				return "login";
			}

		} else {

			return "login";

		}

	}

	// save user details

	@PostMapping("/saveuserdetails")
	public String saveUserDetails(@ModelAttribute NewsAppsUser appsUser) {

		userRepository.save(appsUser);
		
		return "redirect:/login";
	}
	
	
	
	
	
	@GetMapping("/api")
	public String getApi(Model model) {
		
		NewsAppAttributes  obj = newsAppsUserService.consumeApi();
		List<Article> articles = obj.getArticles();

		for (Article article : articles) {
		    System.out.println("Title: " + article.getTitle());
		    System.out.println("Author: " + article.getAuthor());
		    // Other article details can be accessed similarly
		}
		model.addAttribute("articles",articles);
		 
		
	//	
		
		return  "NewsShow";
		
	}
	
	
	
	
	
	
	
	
	
	
	
	
	
	

}
