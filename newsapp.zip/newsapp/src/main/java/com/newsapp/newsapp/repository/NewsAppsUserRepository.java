/**
 * 
 */
package com.newsapp.newsapp.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.newsapp.newsapp.entity.NewsAppsUser;

/**
 * @author Lenovo
 *
 */
@Repository
public interface NewsAppsUserRepository extends JpaRepository<NewsAppsUser, Integer>{

	/**
	 * @param username
	 * @param password
	 * @return
	 */
	@Query(value = "select * from news_apps_user where email =?1 and password = ?2",nativeQuery = true)
	List<NewsAppsUser> getUserDetails(String username, String password);

}
