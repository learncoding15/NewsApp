/**
 * 
 */
package com.newsapp.newsapp.config;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.web.client.RestTemplate;

/**
 * @author Lenovo
 *
 */
@Configuration
public class Config {
	// they generate to us api template where can access the api 
	@Bean
	public RestTemplate restTemplate() {
		return new RestTemplate();
	}

}
