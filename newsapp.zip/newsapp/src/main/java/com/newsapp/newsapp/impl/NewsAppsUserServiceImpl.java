/**
 * 
 */
package com.newsapp.newsapp.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import com.newsapp.newsapp.entity.NewsAppAttributes;
import com.newsapp.newsapp.entity.NewsAppsUser;
import com.newsapp.newsapp.repository.NewsAppsUserRepository;
import com.newsapp.newsapp.service.NewsAppsUserService;

/**
 * @author Lenovo
 *
 */
@Service
public class NewsAppsUserServiceImpl implements NewsAppsUserService {

	@Autowired
	NewsAppsUserRepository appsUserRepository;

	@Autowired
	private RestTemplate restTemplate;

	/**
	 * @param restTemplate
	 */
	public NewsAppsUserServiceImpl(RestTemplate restTemplate) {
		super();
		this.restTemplate = restTemplate;
	}

	public NewsAppAttributes consumeApi() {

		return restTemplate.getForObject("https://newsapi.org/v2/everything?q=apple&from=2023-11-07&to=2023-11-07&sortBy=popularity&apiKey=2e47208e281c4a61af46faecdc6c684a", NewsAppAttributes.class);

	}

	@Override
	public boolean validateUser(String username, String password) {

		List<NewsAppsUser> userDetails = appsUserRepository.getUserDetails(username, password);

		if (userDetails.size() != 0) {

			return true;

		}

		return false;
		// TODO Auto-generated method stub

	}

}
