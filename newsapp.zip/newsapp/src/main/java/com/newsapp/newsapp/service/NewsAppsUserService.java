/**
 * 
 */
package com.newsapp.newsapp.service;

import com.newsapp.newsapp.entity.NewsAppAttributes;

/**
 * @author Lenovo
 *
 */

public interface NewsAppsUserService {

	/**
	 * @param username
	 * @param password
	 */
	boolean validateUser(String username, String password);

	public NewsAppAttributes consumeApi();

}
